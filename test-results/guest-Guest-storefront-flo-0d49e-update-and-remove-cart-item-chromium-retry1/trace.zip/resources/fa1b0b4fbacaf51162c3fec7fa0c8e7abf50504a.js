(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_error_tsx_b0d3c2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_error_tsx_b0d3c2._.js",
  "chunks": [
    "static/chunks/app_[locale]_error_tsx_10beae._.js"
  ],
  "source": "dynamic"
});
