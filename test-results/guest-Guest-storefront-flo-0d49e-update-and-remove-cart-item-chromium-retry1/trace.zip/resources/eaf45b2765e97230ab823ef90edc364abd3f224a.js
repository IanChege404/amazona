(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(root)_cart_page_tsx_122c71._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(root)_cart_page_tsx_122c71._.js",
  "chunks": [
    "static/chunks/_af18e0._.js",
    "static/chunks/node_modules_c16a36._.js"
  ],
  "source": "dynamic"
});
