(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/node_modules_next_dist_client_components_not-found-error_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/node_modules_next_dist_client_components_not-found-error_61af54.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_5d579c._.js"
  ],
  "source": "dynamic"
});
