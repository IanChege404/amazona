(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(root)_layout_tsx_b0d3c2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(root)_layout_tsx_b0d3c2._.js",
  "chunks": [
    "static/chunks/_23d6e3._.js",
    "static/chunks/node_modules_24882d._.js"
  ],
  "source": "dynamic"
});
