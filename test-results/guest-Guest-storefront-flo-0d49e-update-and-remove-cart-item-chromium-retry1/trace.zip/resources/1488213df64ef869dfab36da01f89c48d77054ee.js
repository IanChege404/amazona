(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(root)_cart_[itemId]_page_tsx_122c71._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(root)_cart_[itemId]_page_tsx_122c71._.js",
  "chunks": [
    "static/chunks/_857f01._.js",
    "static/chunks/node_modules_941b37._.js"
  ],
  "source": "dynamic"
});
