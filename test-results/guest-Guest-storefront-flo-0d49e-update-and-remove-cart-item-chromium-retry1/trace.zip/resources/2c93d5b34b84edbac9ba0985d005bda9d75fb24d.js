(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_not-found_tsx_b0d3c2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_not-found_tsx_b0d3c2._.js",
  "chunks": [
    "static/chunks/app_[locale]_not-found_tsx_4a0b66._.js"
  ],
  "source": "dynamic"
});
