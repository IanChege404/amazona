(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__9d1267._.css",
    "static/chunks/_afe0b3._.js",
    "static/chunks/node_modules_e21a7b._.js"
  ],
  "source": "dynamic"
});
